package com.twelevfactorsapp.hcl.zuulsvr.model;

import java.io.Serializable;

public class Customer implements Serializable {

	private static final long serialVersionUID = 1L;

	private String UUID;

	private boolean isUUIDPresent;

	public Customer() {
	}

	public Customer(String uUID) {
		super();
		UUID = uUID;
	}

	public String getUUID() {
		return UUID;
	}

	public void setUUID(String uUID) {
		UUID = uUID;
	}

	public boolean isUUIDPresent() {
		return isUUIDPresent;
	}

	public void setUUIDPresent(boolean isUUIDPresent) {
		this.isUUIDPresent = isUUIDPresent;
	}

}