package com.twelevfactorsapp.hcl.zuulsvr.filters;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;
import com.twelevfactorsapp.hcl.zuulsvr.model.Customer;

@Component
public class SpecialRoutesFilter extends ZuulFilter {
	private static final int FILTER_ORDER = 1;
	private static final boolean SHOULD_FILTER = true;

	@Autowired
	FilterUtils filterUtils;

	@Autowired
	RestTemplate restTemplate;

	@Override
	public String filterType() {
		return FilterUtils.ROUTE_FILTER_TYPE;
	}

	@Override
	public int filterOrder() {
		return FILTER_ORDER;
	}

	@Override
	public boolean shouldFilter() {
		return SHOULD_FILTER;
	}

	public boolean useSpecialRoute() {
		RequestContext ctx = RequestContext.getCurrentContext();
		HttpServletRequest request = ctx.getRequest();
		Cookie[] cookies = request.getCookies();
		boolean useSpecialRoute = false;
		System.out.println("I am inside SpecialRouter checking cookie[uuid]");
		if (cookies != null && !ctx.getRequest().getRequestURI().contains("/api/login")) {
			for (Cookie cookie : cookies) {
				if ("uuid".equalsIgnoreCase(cookie.getName())) {
					System.out.println("I am inside SpecialRouter checking cookie[uuid] now forloop vala "
							+ ctx.getRequest().getRequestURI());
					System.out.println("cookie[uuid] value is " + cookie.getValue());
					if (!ctx.getRequest().getRequestURI().contains("/api/login")
							&& !isCookieValid(cookie.getValue())) {
						useSpecialRoute = true;
						break;
					}
				}
			} // end for loop
		} else if (cookies == null && !ctx.getRequest().getRequestURI().contains("/api/login")) {
			useSpecialRoute = true;
		}

		return useSpecialRoute;
	}

	private boolean isCookieValid(String cookieValue) {
		boolean isCookieValid = false;
		ResponseEntity<Customer> restExchange = null;
		try {
			if("".equals(cookieValue)) {
				return isCookieValid;
			}
			restExchange = restTemplate.exchange("http://redisservice/check/{uuid}", HttpMethod.GET, null,
					Customer.class, cookieValue);
			isCookieValid = restExchange.getBody().isUUIDPresent();
		} catch (HttpClientErrorException ex) {
			if (ex.getStatusCode() == HttpStatus.UNAUTHORIZED) {
				return isCookieValid;
			}
			throw ex;
		}
		return isCookieValid;
	}

	@Override
	public Object run() {
		RequestContext ctx = RequestContext.getCurrentContext();

		try {
			if (useSpecialRoute()) {
				HttpServletRequest request = ctx.getRequest();
				Cookie[] cookies = request.getCookies();
				if (cookies != null) {
					for (Cookie cookie : cookies) {
						if ("uuid".equalsIgnoreCase(cookie.getName())) {
							RequestContext.getCurrentContext().getResponse()
									.sendRedirect("http://localhost:5555/api/login/hello");
							break;
						}
					} // end for loop
				} else {
					RequestContext.getCurrentContext().getResponse().sendRedirect("http://localhost:5555/api/login/hello");
				}
			}
		} catch (java.io.IOException e) {
			e.printStackTrace();
		} catch (java.lang.Exception e) {
			e.printStackTrace();
		}


		return null;
	}

}
