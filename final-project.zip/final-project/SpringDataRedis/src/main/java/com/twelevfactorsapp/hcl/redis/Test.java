package com.twelevfactorsapp.hcl.redis;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.twelevfactorsapp.hcl.redis.model.Customer;

public class Test {

	static ObjectMapper mapper = new ObjectMapper();
	public static void main(String[] args) throws JsonProcessingException {
		convertJavaToJson();
		
	}
	
	public static void convertJavaToJson() throws JsonProcessingException {
		Customer codePath = new Customer(); 
		String jsonInString = mapper.writeValueAsString(codePath);
		
		System.out.println(jsonInString);
	}

}
