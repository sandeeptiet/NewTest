package com.twelevfactorsapp.hcl.redis.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.twelevfactorsapp.hcl.redis.model.Customer;
import com.twelevfactorsapp.hcl.redis.repository.RedisRepository;

@RestController
public class WebController {

	@Autowired
	private RedisRepository redisRepository;

	/*@RequestMapping(value = "/save/{uuid}", method = RequestMethod.POST)
	public ResponseEntity<String> save(@PathVariable("uuid") String uuid) {
		Customer customer = new Customer();
		customer.setUUID(uuid);
		redisRepository.save(customer);
		return new ResponseEntity<>(HttpStatus.OK);
	}*/
	
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public Customer save(@RequestBody Customer customer) {
		System.out.println("in side redis service save method" + customer.getAuthorities());
		return redisRepository.save(customer);
		//return new ResponseEntity<>(HttpStatus.CREATED);
	}

	@RequestMapping(value = "/check/{uuid}", method = RequestMethod.GET)
	public Customer findCustomer(@PathVariable("uuid") String uuid) {
		return redisRepository.findByUUID(uuid);
	}

	@RequestMapping(value = "/findall", method = RequestMethod.GET)
	public Map<Object, Object> findAll() {
		Map<Object, Object> customers = redisRepository.findAll();
		return customers;
	}

	@RequestMapping(value = "/delete/{uuid}", method = RequestMethod.GET)
	public ResponseEntity<String> deleteById(@PathVariable("uuid") String uuid) {
		System.out.println("inside redis service delete function " + uuid);
		redisRepository.delete(uuid);
		return new ResponseEntity<>(HttpStatus.OK);
	}
}
