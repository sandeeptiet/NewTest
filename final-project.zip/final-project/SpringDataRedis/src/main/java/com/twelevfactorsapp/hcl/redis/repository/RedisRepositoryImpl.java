package com.twelevfactorsapp.hcl.redis.repository;

import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Repository;

import com.twelevfactorsapp.hcl.redis.model.Customer;

@Repository
public class RedisRepositoryImpl implements RedisRepository {
	private static final String KEY = "Customer";

	private RedisTemplate<String, Object> redisTemplate;
	private HashOperations<String, Object, Object> hashOperations;

	@Autowired
	public RedisRepositoryImpl(RedisTemplate<String, Object> redisTemplate) {
		this.redisTemplate = redisTemplate;
	}

	@PostConstruct
	private void init() {
		hashOperations = redisTemplate.opsForHash();
	}

	public void delete(final String uuid) {
		hashOperations.delete(KEY, uuid);
	}

	@Override
	public Customer findByUUID(String uUID) {
		Customer cust = new Customer();
		if(hashOperations.get(KEY, uUID) != null) {
			cust.setUUID(uUID);
			cust.setUUIDPresent(true);
			
		}
		return cust;
	}

	@Override
	public Customer save(Customer customer) {
		hashOperations.put(KEY, customer.getUUID(), customer);
		return null;
	}

	@Override
	public Map<Object, Object> findAll() {
		return hashOperations.entries(KEY);
	}

}
