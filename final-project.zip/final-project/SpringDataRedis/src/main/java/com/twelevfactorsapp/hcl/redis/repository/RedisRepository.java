package com.twelevfactorsapp.hcl.redis.repository;

import java.util.Map;

import com.twelevfactorsapp.hcl.redis.model.Customer;

public interface RedisRepository  {

	public Customer findByUUID(String uUID);

	public Customer save(Customer entity);
	
	public Map<Object, Object> findAll();

	public void delete(String uuid);
}
