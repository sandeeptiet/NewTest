package com.twelevfactorsapp.hcl.redis.model;

import java.io.Serializable;

import org.springframework.data.annotation.Id;

public class Customer implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	private String UUID;
	private boolean isUUIDPresent;
	private String username;
	private String authorities;

	private String accessToken;

	public Customer() {
	}

	public Customer(String uUID) {
		super();
		UUID = uUID;
	}

	public String getUUID() {
		return UUID;
	}

	public void setUUID(String uUID) {
		UUID = uUID;
	}

	public boolean isUUIDPresent() {
		return isUUIDPresent;
	}

	public void setUUIDPresent(boolean isUUIDPresent) {
		this.isUUIDPresent = isUUIDPresent;
	}

	public String getAccessToken() {
		return accessToken;
	}

	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getAuthorities() {
		return authorities;
	}

	public void setAuthorities(String authorities) {
		this.authorities = authorities;
	}

}