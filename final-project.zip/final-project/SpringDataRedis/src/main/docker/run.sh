#!/bin/sh
echo "********************************************************"
echo "Starting the Redis Server"
echo "********************************************************"
java -Djava.security.egd=file:/dev/./urandom -jar /usr/local/redisservice/@project.build.finalName@.jar
