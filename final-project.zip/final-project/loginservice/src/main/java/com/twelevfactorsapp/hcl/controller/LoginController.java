package com.twelevfactorsapp.hcl.controller;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.twelevfactorsapp.hcl.VO.MyResponseVO;
import com.twelevfactorsapp.hcl.model.Customer;
import com.twelevfactorsapp.hcl.model.Greeting;

@RestController
@CrossOrigin("*")
public class LoginController {

	@Autowired
	RestTemplate restTemplate;
	@Autowired
	HttpServletResponse httpResponse;

	@RequestMapping(value = "/hello", method = RequestMethod.GET)
	public Greeting testHello() {
		return new Greeting(1, "Hello world!");
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public ResponseEntity<MyResponseVO> getAuthenticatedData(HttpServletResponse httpResponse)
			throws URISyntaxException {
		RequestEntity request = RequestEntity.post(new URI("http://authenticationservice/auth/oauth/token"))
				.header("content-type", "multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW")
				.header("authorization", "Basic ZWFnbGVleWU6dGhpc2lzc2VjcmV0").header("cache-control", "no-cache")
				.header("postman-token", "61221986-9ea4-9d74-7826-3dd4122ab857")
				.body("------WebKitFormBoundary7MA4YWxkTrZu0gW\r\nContent-Disposition: form-data; name=\"grant_type\"\r\n\r\npassword\r\n------WebKitFormBoundary7MA4YWxkTrZu0gW\r\nContent-Disposition: form-data; name=\"scope\"\r\n\r\nwebclient\r\n------WebKitFormBoundary7MA4YWxkTrZu0gW\r\nContent-Disposition: form-data; name=\"username\"\r\n\r\njohn.carnell\r\n------WebKitFormBoundary7MA4YWxkTrZu0gW\r\nContent-Disposition: form-data; name=\"password\"\r\n\r\npassword1\r\n------WebKitFormBoundary7MA4YWxkTrZu0gW--");

		ResponseEntity<MyResponseVO> response = restTemplate.exchange(request, MyResponseVO.class);

		if (response != null && response.getBody() != null && response.getBody().getAccess_token() != null) {
			String uuid = UUID.randomUUID().toString();
			Cookie uuidCookie = new Cookie("uuid", uuid);
			uuidCookie.setHttpOnly(true);
			uuidCookie.setMaxAge(-1);
			uuidCookie.setSecure(false);
			uuidCookie.setPath("/");
			httpResponse.addCookie(uuidCookie);
			// Save access_token, uuid, expiry, refresh_token, user_name etc into Redis
			
			ResponseEntity<String> responseEntity = null;
			ResponseEntity<Map> userInfo = null;
			try {
				HttpHeaders headers = new HttpHeaders();
				headers.add("Authorization", "Bearer "+response.getBody().getAccess_token());
				HttpEntity entity = new HttpEntity(headers);
				userInfo = restTemplate.exchange("http://authenticationservice/auth/user", HttpMethod.GET, entity, Map.class, "");
				System.out.println("User Info from LoginService" + userInfo.getBody().get("authorities").toString());
				Customer customer = new Customer();
				customer.setAuthorities(userInfo.getBody().get("authorities").toString());
				customer.setUsername(userInfo.getBody().get("user").toString());
				customer.setUUID(uuid);
				customer.setUUIDPresent(true);
				
				/*RequestEntity requestToSaveUserInfo = RequestEntity
					     .post(new URI("http://localhost:9654/save"))
					     .accept(MediaType.APPLICATION_JSON)
					     .body(custEntity);
				 responseEntity = restTemplate.exchange(requestToSaveUserInfo, String.class);*/
				 MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
				 map.add("Content-Type", MediaType.APPLICATION_JSON.toString());
				HttpEntity<Customer> custEntity = new HttpEntity(customer, map);
				restTemplate.exchange(new URI("http://redisservice/save"), HttpMethod.POST, custEntity, Customer.class);
				//responseEntity = restTemplate.postForEntity("http://localhost:9654/save", custEntity, Customer.class);
				
				/*responseEntity = restTemplate.exchange("http://redisservice/save/{uuid}", HttpMethod.POST,
						null, String.class, uuid);*/
			} catch (HttpClientErrorException ex) {
				if (ex.getStatusCode() == HttpStatus.UNAUTHORIZED) {
					return null;
				}
				throw ex;
			}
		}
		return response;

	}
}
