package com.twelevfactorsapp.hcl.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.twelevfactorsapp.hcl.model.SearchMetaData;

public interface SearchMetaDataRepository extends MongoRepository<SearchMetaData, String>, SearchMetaDataRepositoryCustom {
	public List<SearchMetaData> findByUUID(String uUID);
	
}
