package com.twelevfactorsapp.hcl.constants;

public class LoggingConstants {

	public static final String LOG4J_RECOMMENDATION = "You are using log4j logging framework with File Appenders. It is recommended to use console appenders for becoming cloud native instead of using files to log the data.";
	public static final String LOGBACK_RECOMMENDATION = "You are using logback framework with FileAppender. It is recommended to use console appenders for becoming cloud native instead of using files to log the data.";
	public static final String LOG4J_ROLLINGFILE_APPENDER_KEYWORD = "org.apache.log4j.RollingFileAppender";
	public static final String LOG4J_FILE_APPENDER_KEYWORD = "log4j.appender.file";
	
}
