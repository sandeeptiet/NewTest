package com.twelevfactorsapp.hcl.model;

import java.util.Collection;

import org.springframework.stereotype.Component;

@Component
public class SearchResults {
	String filePath;
	Collection<String> codeLines;
	String error;
	String recommendations;

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	public Collection<String> getCodeLines() {
		return codeLines;
	}

	public void setCodeLines(Collection<String> codeLines) {
		this.codeLines = codeLines;
	}

	public String getRecommendations() {
		return recommendations;
	}

	public void setRecommendations(String recommendations) {
		this.recommendations = recommendations;
	}

}
