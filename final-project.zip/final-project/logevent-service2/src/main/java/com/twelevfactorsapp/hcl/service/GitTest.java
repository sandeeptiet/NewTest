package com.twelevfactorsapp.hcl.service;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;

import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.lib.Constants;
import org.eclipse.jgit.lib.ObjectId;
import org.eclipse.jgit.lib.ObjectLoader;
import org.eclipse.jgit.lib.Repository;
import org.eclipse.jgit.revwalk.RevCommit;
import org.eclipse.jgit.revwalk.RevTree;
import org.eclipse.jgit.revwalk.RevWalk;
import org.eclipse.jgit.treewalk.TreeWalk;
import org.eclipse.jgit.treewalk.filter.PathFilter;

public class GitTest {

		public static void main(String[] args) throws Exception
		  {
		    File gitWorkDir = new File("C:/temp/gittest/");
		    Git git = Git.open(gitWorkDir);
		    Repository repo = git.getRepository();
		 
		    ObjectId lastCommitId = repo.resolve(Constants.HEAD);
		 
		    RevWalk revWalk = new RevWalk(repo);
		    RevCommit commit = revWalk.parseCommit(lastCommitId);
		 
		    RevTree tree = commit.getTree();
		 
		    TreeWalk treeWalk = new TreeWalk(repo);
		    treeWalk.addTree(tree);
		    treeWalk.setRecursive(true);
		    treeWalk.setFilter(PathFilter.create("file1.txt"));
		    if (!treeWalk.next()) 
		    {
		      System.out.println("Nothing found!");
		      return;
		    }
		 
		    ObjectId objectId = treeWalk.getObjectId(0);
		    ObjectLoader loader = repo.open(objectId);
		 
		    ByteArrayOutputStream out = new ByteArrayOutputStream();
		    loader.copyTo(out);
		    System.out.println("file1.txt:\n" + out.toString());
		    }
		/*Repository repository = Git
				.open(new File("https://github.com/sandeeptiet/Web-Services-demos-by-Sandeep-Kapoor.git"))
				.getRepository();

		// find the HEAD
		ObjectId lastCommitId = repository.resolve(Constants.HEAD);

		// a RevWalk allows to walk over commits based on some filtering that is defined
		try (RevWalk revWalk = new RevWalk(repository)) {
			RevCommit commit = revWalk.parseCommit(lastCommitId);
			// and using commit's tree find the path
			RevTree tree = commit.getTree();
			System.out.println("Having tree: " + tree);

			// now try to find a specific file
			try (TreeWalk treeWalk = new TreeWalk(repository)) {
				treeWalk.addTree(tree);
				treeWalk.setRecursive(true);
				ObjectId objectId = treeWalk.getObjectId(0);
				ObjectLoader loader = repository.open(objectId);

				// and then one can the loader to read the file
				//loader.copyTo(System.out);
			}

			revWalk.dispose();
		}
*/
	}

