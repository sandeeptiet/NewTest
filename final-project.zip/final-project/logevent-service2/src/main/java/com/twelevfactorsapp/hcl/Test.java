package com.twelevfactorsapp.hcl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.twelevfactorsapp.hcl.model.CodePath;

public class Test {
	
	public static void main(String[] args) {
		/*String route = buildRouteString("http://organizationservice:8086",
                "http://orgservice-new:8087",
                "organizationservice");
		System.out.println("Route " + route);*/
		String matches = ".gemfire.repository.config.EnableGemfireRepositories";
		if(matches.contains(".gemfire.")) {
			System.out.println("done ...");
		} else {
			System.out.println("not done ...");
		}
	}
	
	 /*private static String buildRouteString(String oldEndpoint, String newEndpoint, String serviceName){
	       
	        return String.format("%s/%s", "http://localhost:5555", "/api/login/hello");
	        
	        // we need to build new route (new Endpoint ) if cookie[uuid] is empty o not valid. Sandeep
	    }
	static ObjectMapper mapper = new ObjectMapper();
	public static void main(String[] args) throws JsonProcessingException {
		convertJavaToJson();
		
	}
	
	public static void convertJavaToJson() throws JsonProcessingException {
		CodePath codePath = new CodePath(); 
		String jsonInString = mapper.writeValueAsString(codePath);
		
		System.out.println(jsonInString);
	}*/
	
	
}
