package com.twelevfactorsapp.hcl.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.twelevfactorsapp.hcl.model.CodePath;
import com.twelevfactorsapp.hcl.model.ReportData;
import com.twelevfactorsapp.hcl.model.ReportMetaData;
import com.twelevfactorsapp.hcl.model.SearchMetaData;
import com.twelevfactorsapp.hcl.model.SearchResults;
import com.twelevfactorsapp.hcl.service.GrepService;

@RestController
@CrossOrigin("*")
public class TwelevFactorComplianceController {

	@Autowired
	Environment env;

	@Autowired
	GrepService grepService;

	@Autowired
	CodePath codePath;

	@Autowired
	SearchResults results;

	//@PreAuthorize("hasAuthority('ADMIN')")
	@RequestMapping(value = "/logevent2", method = RequestMethod.POST)
	public List<SearchResults> checkLogEventFactor(@RequestBody CodePath codePath) throws IOException {
		List<SearchResults> listSearchResults = null;
		boolean isGitPath = false;
		if (codePath.getPath() != null && !codePath.getPath().isEmpty()) {
			listSearchResults = grepService.search(codePath.getPath(), env.getProperty("pattern"), isGitPath,
					codePath.getSearchTagName());
		} else if (codePath.getGitPath() != null && !codePath.getGitPath().isEmpty()) {
			isGitPath = true;
			listSearchResults = grepService.search(codePath.getGitPath(), env.getProperty("pattern"), isGitPath,
					codePath.getSearchTagName());
		} else {
			listSearchResults = new ArrayList<>();
			results.setError("No valid code path is mentioned.");
			listSearchResults.add(results);
		}

		return listSearchResults;
	}

	@RequestMapping(value = "/getSearchHistory2/{uuid}", method = RequestMethod.GET)
	public List<SearchMetaData> getSearchHistory(@PathVariable("uuid") String uuid) throws IOException {
		return grepService.getSearchHistory(uuid);
	}

	@RequestMapping(value = "/report2/{uuid}/{tagName}", method = RequestMethod.GET)
	public ReportData reportLogEventFactor(@PathVariable("uuid") String uuid,
			@PathVariable("tagName") String tagName) throws IOException {
		ReportData reportData = new ReportData();
		//SearchMetaData searchMetaData = grepService.getSearchMetaDataByUUIDAndTagName(uuid, tagName);
		SearchMetaData searchMetaData = new SearchMetaData();
		if (searchMetaData != null) {
			//reportData = grepService.getReport(searchMetaData.getLocalGitRepoPath(), env.getProperty("pattern"));
			//"C:\\Users\\sandeep-ka\\Downloads\\labs\\modern-coolstore\\cart-service"
			String localGitRepoPath = "C:\\gitRepo\\-2145449871";
			reportData = grepService.getReport(localGitRepoPath, env.getProperty("pattern"));
			//ReportMetaData reportMetaData = grepService.reportMetaDataService(searchMetaData.getLocalGitRepoPath(), env.getProperty("metadataPattern"));
			ReportMetaData reportMetaData = grepService.reportMetaDataService(localGitRepoPath, env.getProperty("metadataPattern"));
			reportData.setReportMetaData(reportMetaData);		
		} else {
			reportData.setError("No valid code path is mentioned.");
		}

		return reportData;
	}

}
