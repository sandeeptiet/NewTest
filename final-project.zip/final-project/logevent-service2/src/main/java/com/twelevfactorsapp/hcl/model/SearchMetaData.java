package com.twelevfactorsapp.hcl.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.TypeAlias;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
@TypeAlias("SearchMetaData")
public class SearchMetaData {

	@Id
	private String id;

	private String uUID;
	private String localGitRepoPath;
	private String tagName;

	public SearchMetaData() {
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
	
	public String getuUID() {
		return uUID;
	}

	public void setuUID(String uUID) {
		this.uUID = uUID;
	}

	public String getLocalGitRepoPath() {
		return localGitRepoPath;
	}

	public void setLocalGitRepoPath(String localGitRepoPath) {
		this.localGitRepoPath = localGitRepoPath;
	}

	public String getTagName() {
		return tagName;
	}

	public void setTagName(String tagName) {
		this.tagName = tagName;
	}

}
