package com.twelevfactorsapp.hcl.model;

public class ReportMetaData {

	private String javaVersion;
	private String totalNoOfLines;
	private String deploymentPackageing;

	public String getJavaVersion() {
		return javaVersion;
	}

	public void setJavaVersion(String javaVersion) {
		this.javaVersion = javaVersion;
	}

	public String getTotalNoOfLines() {
		return totalNoOfLines;
	}

	public void setTotalNoOfLines(String totalNoOfLines) {
		this.totalNoOfLines = totalNoOfLines;
	}

	public String getDeploymentPackageing() {
		return deploymentPackageing;
	}

	public void setDeploymentPackageing(String deploymentPackageing) {
		this.deploymentPackageing = deploymentPackageing;
	}

}
