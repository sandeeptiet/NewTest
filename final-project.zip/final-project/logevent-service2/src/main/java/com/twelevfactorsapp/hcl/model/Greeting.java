package com.twelevfactorsapp.hcl.model;

import org.springframework.stereotype.Component;

@Component
public class Greeting {
	String greeting;
	String name;

	public String getGreeting() {
		return greeting;
	}

	public void setGreeting(String greeting) {
		this.greeting = greeting;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
