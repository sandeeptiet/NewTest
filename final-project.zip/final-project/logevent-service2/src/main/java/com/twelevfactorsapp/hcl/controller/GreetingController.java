package com.twelevfactorsapp.hcl.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.twelevfactorsapp.hcl.model.Greeting;

@RestController
public class GreetingController {

	@Autowired
	Greeting greet;

	@RequestMapping(value="/greeting", method = RequestMethod.GET)
	public Greeting greeting(@RequestParam(name = "name", required = false, defaultValue = "World") String name) {
		greet.setGreeting("Hello");
		greet.setName(name);
		return greet;
	}

}
