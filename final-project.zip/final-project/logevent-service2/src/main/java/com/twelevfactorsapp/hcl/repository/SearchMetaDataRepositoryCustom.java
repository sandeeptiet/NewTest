package com.twelevfactorsapp.hcl.repository;

import com.twelevfactorsapp.hcl.model.SearchMetaData;

public interface SearchMetaDataRepositoryCustom {
	public SearchMetaData getSearchMetaDataByUUIDAndTagName(String uUID, String tagName);
	public void deleteSearchMetaDataByUUIDAndTagName(String uUID, String tagName);
}
