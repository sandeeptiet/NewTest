package com.twelevfactorsapp.hcl.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

// it is a tranfer object. nothing to do with db. so can be moved out from model/domain package.
public class ReportData {
	List<SearchResults> listSearchResults;
	Integer noOfFilesNeedChanges;
	String buildTool;
	String error;
	Map<String, Long> map = new HashMap<>();
	ReportMetaData reportMetaData = new ReportMetaData();
	

	public ReportMetaData getReportMetaData() {
		return reportMetaData;
	}

	public void setReportMetaData(ReportMetaData reportMetaData) {
		this.reportMetaData = reportMetaData;
	}

	public Map<String, Long> getMap() {
		return map;
	}

	public void setMap(Map<String, Long> map) {
		this.map = map;
	}

	public List<SearchResults> getListSearchResults() {
		return listSearchResults;
	}

	public void setListSearchResults(List<SearchResults> listSearchResults) {
		this.listSearchResults = listSearchResults;
	}

	public Integer getNoOfFilesNeedChanges() {
		return noOfFilesNeedChanges;
	}

	public void setNoOfFilesNeedChanges(Integer noOfFilesNeedChanges) {
		this.noOfFilesNeedChanges = noOfFilesNeedChanges;
	}

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}

	public String getBuildTool() {
		return buildTool;
	}

	public void setBuildTool(String buildTool) {
		this.buildTool = buildTool;
	}

}
