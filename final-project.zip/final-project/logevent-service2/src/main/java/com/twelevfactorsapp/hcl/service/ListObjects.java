package com.twelevfactorsapp.hcl.service;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.FileVisitResult;
import java.nio.file.FileVisitor;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.regions.AwsRegionProviderChain;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.ListObjectsV2Result;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.twelevfactorsapp.hcl.model.SearchResults;

/**
 * List objects within an Amazon S3 bucket.
 *
 * This code expects that you have AWS credentials set up per:
 * http://docs.aws.amazon.com/java-sdk/latest/developer-guide/setup-credentials.html
 */
public class ListObjects extends AwsRegionProviderChain {
	public static void main(String[] args) {
		final String USAGE = "\n" + "To run this example, supply the name of a bucket to list!\n" + "\n"
				+ "Ex: ListObjects <bucket-name>\n";

		if (args.length < 1) {
			System.out.println(USAGE);
			System.exit(1);
		}

		String bucket_name = args[0];
		String pattern = ".*(log4j.appender.file|ch.qos.logback.core.FileAppender|org.apache.log4j.RollingFileAppender|ch.qos.logback.core.rolling.RollingFileAppender|tinylog.writer.filename).*";
		System.out.println("pattern is :::" +bucket_name + "   " + pattern);

		System.out.format("Objects in S3 bucket %s:\n", bucket_name);
		//final AmazonS3 s3 = AmazonS3ClientBuilder.defaultClient();
		AmazonS3 s3 = AmazonS3Client.builder().withRegion("us-east-1").withForceGlobalBucketAccessEnabled(true).build();
		//client.getBucketLocation("your-eu-west-1-bucket");
		ListObjectsV2Result result = s3.listObjectsV2(bucket_name);
		List<S3ObjectSummary> objects = result.getObjectSummaries();
		for (S3ObjectSummary os : objects) {
			System.out.println("* " + os.getKey());
			//searchService(os.getKey(), pattern, bucket_name, s3, os.getKey());
		}
	}
	
	private static  List<SearchResults> searchService(String path, String pattern, String bucket_name, AmazonS3 s3, String key_name) {
		List<SearchResults> listSearchResults = new ArrayList<>();
		try {
			S3Object o = s3.getObject(bucket_name, key_name);
			S3ObjectInputStream s3is = o.getObjectContent();
			FileOutputStream fos = new FileOutputStream(new File(key_name));
			byte[] read_buf = new byte[1024];
			int read_len = 0;
			while ((read_len = s3is.read(read_buf)) > 0) {
				fos.write(read_buf, 0, read_len);
			}
			
			s3is.close();
			fos.close();
		} catch (AmazonServiceException e) {
			System.err.println(e.getErrorMessage());
			System.exit(1);
		} catch (FileNotFoundException e) {
			System.err.println(e.getMessage());
			System.exit(1);
		} catch (IOException e) {
			System.err.println(e.getMessage());
			System.exit(1);
		}
		
		
		try {
			FileVisitor<Path> simpleFileVisitor = new SimpleFileVisitor<Path>() {
				@Override
				public FileVisitResult visitFile(Path visitedFile, BasicFileAttributes fileAttributes)
						throws IOException {
					Pattern r = Pattern.compile(pattern);
					if (visitedFile.toFile().getPath().matches(".*(xml|properties).*")
							&& !visitedFile.toFile().getPath().matches(".*\\target\\.*")) {
						Stream<String> strString = grep(visitedFile.toFile().getPath(), pattern);
						List<String> list = new ArrayList<String>();
						strString.forEach(line -> {
							SearchResults searchResults = new SearchResults();
							if (Pattern.matches(pattern, line)) {
								Matcher m = r.matcher(line);
								if (m.find()) {
									searchResults.setFilePath(visitedFile.toFile().getPath());
									list.add(line);
									searchResults.setCodeLines(list);
								}
								listSearchResults.add(searchResults);
							}
						});
					}
					
					return FileVisitResult.CONTINUE;
				}
			};
			FileSystem fileSystem = FileSystems.getDefault();
			Path rootPath = fileSystem.getPath(path); // path
			Files.walkFileTree(rootPath, simpleFileVisitor);
		} catch (IOException ioe) {
		}
		return listSearchResults;
	}

	public static Stream<String> grep(String path, String pattern) throws IOException {

		return Files.lines(Paths.get(path), StandardCharsets.ISO_8859_1).filter(line -> line.matches(pattern));
	}
	
}