package com.twelevfactorsapp.hcl.model;

import org.springframework.stereotype.Component;

/**
 * @author sandeep-ka
 *
 */
@Component
public class CodePath {
	String path;
	String gitPath;
	String searchTagName;

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getGitPath() {
		return gitPath;
	}

	public void setGitPath(String gitPath) {
		this.gitPath = gitPath;
	}

	public String getSearchTagName() {
		return searchTagName;
	}

	public void setSearchTagName(String searchTagName) {
		this.searchTagName = searchTagName;
	}

}
