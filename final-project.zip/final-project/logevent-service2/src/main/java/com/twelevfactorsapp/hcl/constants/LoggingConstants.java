package com.twelevfactorsapp.hcl.constants;

public class LoggingConstants {

	public static final String LOG4J_RECOMMENDATION = "You are using log4j logging framework with File Appenders. It is recommended to use console appenders for becoming cloud native instead of using files to log the data.";
	public static final String LOGBACK_RECOMMENDATION = "You are using logback framework with FileAppender. It is recommended to use console appenders for becoming cloud native instead of using files to log the data.";
	public static final String LOG4J_ROLLINGFILE_APPENDER_KEYWORD = "org.apache.log4j.RollingFileAppender";
	public static final String LOG4J_FILE_APPENDER_KEYWORD = "log4j.appender.file";
	public static final String LOGBACK_FILE_APPENDER_KEYWORD = "ch.qos.logback.core.FileAppender";
	public static final String STICKY_SESSION_RECOMMENDATION = "You are using sessions in your code which can lead to sticky session problem. In order to become "
			+ "cloud native ready, please remove the session related code and use some kind of external service"
			+ "like Redis to save the session state.";
	public static final String GEMFIRE_EFFORT_RECOMMENDATION = "This app/service is using Pivotal Gemfire. So its difficulty level is Medium";
	public static final String HAZELCAST_EFFORT_RECOMMENDATION = "This app/service is using Hazelcast. So its difficulty level is Medium";
	public static final String REDIS_EFFORT_RECOMMENDATION = "This app/service is using Redis cache. So its difficulty level is Easy";
	public static final String RABBITMQ_EFFORT_RECOMMENDATION = "This app/service is using RABBITMQ. So its difficulty level is Easy";
	public static final String IBMMQ_EFFORT_RECOMMENDATION = "This app/service is using IBM MQ. So its difficulty level is difficult";
	public static final String JMS_EFFORT_RECOMMENDATION = "This app/service is using JMS. So its difficulty level is medium";
}
