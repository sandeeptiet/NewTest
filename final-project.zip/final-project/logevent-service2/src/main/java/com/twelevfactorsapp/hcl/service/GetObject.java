package com.twelevfactorsapp.hcl.service;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;

/*
Copyright 2010-2018 Amazon.com, Inc. or its affiliates. All Rights Reserved.
This file is licensed under the Apache License, Version 2.0 (the "License").
You may not use this file except in compliance with the License. A copy of
the License is located at
 http://aws.amazon.com/apache2.0/
This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
CONDITIONS OF ANY KIND, either express or implied. See the License for the
specific language governing permissions and limitations under the License.
*/
import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.S3Object;

/**
 * Get an object within an Amazon S3 bucket.
 *
 * This code expects that you have AWS credentials set up per:
 * http://docs.aws.amazon.com/java-sdk/latest/developer-guide/setup-credentials.html
 */
public class GetObject {
	public static void main(String[] args) {
		final String USAGE = "\n" + "To run this example, supply the name of an S3 bucket and object to\n"
				+ "download from it.\n" + "\n" + "Ex: GetObject <bucketname> <filename>\n";

		if (args.length < 2) {
			System.out.println(USAGE);
			System.exit(1);
		}

		String bucket_name = args[0];
		String key_name = "1686733700/WsFinalDemo/pom.xml";

		System.out.format("Downloading %s from S3 bucket %s...\n", key_name, bucket_name);
		//final AmazonS3 s3 = AmazonS3ClientBuilder.defaultClient();
		AmazonS3 s3 = AmazonS3Client.builder().withRegion("us-west-2").withForceGlobalBucketAccessEnabled(true).build();
		try {
			S3Object o = s3.getObject(bucket_name, key_name);
			System.out.println("Content Length :::::::> " + o.getObjectMetadata().getContentLength());
			//S3ObjectInputStream s3is = o.getObjectContent();
			
		    System.out.println(o.getObjectMetadata().getContentType());
		    System.out.println(o.getObjectMetadata().getContentLength());

		    BufferedReader reader = new BufferedReader(new InputStreamReader(o.getObjectContent()));
		    String line = "";
		    while((line = reader.readLine()) != null) {
		      // can copy the content locally as well
		      // using a buffered writer
		      System.out.println(line);
		    }
		} catch (AmazonServiceException e) {
			System.err.println(e.getErrorMessage());
			System.exit(1);
		} catch (FileNotFoundException e) {
			System.err.println(e.getMessage());
			System.exit(1);
		} catch (Exception e) {
			System.err.println(e.getMessage());
			System.exit(1);
		}
		System.out.println("Done!");
	}
}
