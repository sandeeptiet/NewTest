package com.twelevfactorsapp.hcl.service;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.FileVisitResult;
import java.nio.file.FileVisitor;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;

import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.api.errors.InvalidRemoteException;
import org.eclipse.jgit.api.errors.TransportException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.FileSystemUtils;

import com.twelevfactorsapp.hcl.constants.LoggingConstants;
import com.twelevfactorsapp.hcl.model.ReportData;
import com.twelevfactorsapp.hcl.model.ReportMetaData;
import com.twelevfactorsapp.hcl.model.SearchMetaData;
import com.twelevfactorsapp.hcl.model.SearchResults;
import com.twelevfactorsapp.hcl.repository.SearchMetaDataRepository;

@Service
public class GrepService {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	SearchMetaDataRepository searchMetaDataRepository;
	
	public List<SearchResults> search(String gitPath, String pattern, boolean isGitPath, String tagName)
			throws IOException {
		List<SearchResults> listSearchResults = null;
		Map<String, SearchResults> map = new HashMap<>();
		try {
			String localGitRepoPath = null;
			if (isGitPath) {
				// localGitRepoPath = cloneGitRepository(gitPath);
				localGitRepoPath = "C:\\gitRepo\\-2145449871";
				// saveSearchMetaData(localGitRepoPath, tagName);
				listSearchResults = searchService(localGitRepoPath, pattern);
			} else {
				listSearchResults = searchService(gitPath, pattern);
			}
			if (isGitPath) {
				// deleteLocalGitRepo(localGitRepoPath);
			}

			for (SearchResults res : listSearchResults) {
				map.put(res.getFilePath(), res);
			}
			listSearchResults = new ArrayList<>();
			for (String key : map.keySet()) {
				listSearchResults.add(map.get(key));
			}

		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return listSearchResults;
	}

	public ReportData getReport(String gitPath, String pattern) throws IOException {
		ReportData reportData = null;
		ReportData finalReportData = new ReportData();
		List<SearchResults> listSearchResults = new ArrayList<>();
		Map<String, SearchResults> map = new HashMap<>();
		try {
			reportData = reportService(gitPath, pattern);
			for (SearchResults res : reportData.getListSearchResults()) {
				map.put(res.getFilePath(), res);
			}

			for (String key : map.keySet()) {
				listSearchResults.add(map.get(key));
			}

			finalReportData.setListSearchResults(listSearchResults);
			finalReportData.setNoOfFilesNeedChanges(reportData.getNoOfFilesNeedChanges());
			finalReportData.setBuildTool(reportData.getBuildTool());
			finalReportData.setMap(reportData.getMap());
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return finalReportData;
	}

	public ReportData reportService(String path, final String pattern) throws IOException {
		ReportData reportData = new ReportData();
		FileVisitor<Path> simpleFileVisitor = new SimpleFileVisitor<Path>() {
			long noOfFilesScanned = 0;
			// long noOfAffectedLines = 0;
			long codeSize = 0;
			Integer noOfFilesNeedChanges = 0;
			Map<String, Long> map = new HashMap<>();
			
			List<SearchResults> listSearchResults = new ArrayList<>();
			AtomicInteger atomicInteger = new AtomicInteger(1);
			AtomicLong atomicLong = new AtomicLong(1);
			String buildTool = "";
			@Override
			public FileVisitResult visitFile(Path visitedFile, BasicFileAttributes fileAttributes) throws IOException {
				map.put("noOfFilesScanned", noOfFilesScanned++);
				codeSize = codeSize + fileAttributes.size();
				map.put("codeSize", codeSize);
				// map.put("noOfLinesScanned", noOfLinesScanned);
				Pattern r = Pattern.compile(pattern);
				if (visitedFile.toFile().getPath().matches(".*(xml|properties|java|gradle).*")
						&& !visitedFile.toFile().getPath().matches(".*\\target\\.*")) {
					Stream<String> strString = grep(visitedFile.toFile().getPath(), pattern);
					List<String> list = new ArrayList<String>();
					strString.forEach(line -> {
						SearchResults searchResults = new SearchResults();
						map.put("noOfLinesScanned", atomicLong.getAndIncrement());
						atomicInteger.getAndIncrement();
						if (Pattern.matches(pattern, line)) {
							Matcher m = r.matcher(line);
							if (m.find()) {
								searchResults.setRecommendations(getRecommendation(m.group(1)));
								System.out.println(pattern + " matches \"" + m.group(1) + "\" in line number \""
										+ atomicInteger.toString() + "  with line " + line + "\"");
								searchResults.setFilePath(visitedFile.toFile().getPath());
								list.add(line);
								searchResults.setCodeLines(list);
								buildTool = getBuildTool(m.group(1));
							}
							listSearchResults.add(searchResults);

							if (map.put(visitedFile.toFile().getPath(), 1L) == null) {
								noOfFilesNeedChanges++;
							}
							
							if (visitedFile.toFile().getPath().matches(".*(gradle).*")) {
								buildTool = "You are using gradle build tool. So the difficulty level is Small.";
							}
							
							if (visitedFile.toFile().getPath().matches(".*(build.xml).*")) {
								buildTool = "You are using Ant build tool. So the difficulty level is Medium.";
							}
							reportData.setNoOfFilesNeedChanges(noOfFilesNeedChanges);
							reportData.setListSearchResults(listSearchResults);
						}
					});
				}
				
				if(buildTool != null) {
					reportData.setBuildTool(buildTool);
				}
				reportData.setMap(map);
				return FileVisitResult.CONTINUE;
			}
		};

		FileSystem fileSystem = FileSystems.getDefault();
		Path rootPath = fileSystem.getPath(path); // path
		Files.walkFileTree(rootPath, simpleFileVisitor);

		return reportData;
	}

	public ReportMetaData reportMetaDataService(String path, final String pattern) throws IOException {
		ReportMetaData reportMetaData = new ReportMetaData();
		FileSystem fileSystem = FileSystems.getDefault();
		Path rootPath = fileSystem.getPath(path);
		AtomicLong totalNoOfLines = new AtomicLong(0);
		Files.walkFileTree(rootPath, new SimpleFileVisitor<Path>() {
			@Override
			public FileVisitResult visitFile(Path visitedFile, BasicFileAttributes fileAttributes) throws IOException {
				totalNoOfLines.addAndGet(linesCount(visitedFile.toFile().getPath()));
				Pattern r = Pattern.compile(pattern);
				if (visitedFile.toFile().getPath().matches(".*(xml|properties|java|gradle).*")
						&& !visitedFile.toFile().getPath().matches(".*\\target\\.*")) {
					Stream<String> strString = grep(visitedFile.toFile().getPath(), pattern);
					strString.forEach(line -> {
						if (Pattern.matches(pattern, line)) {
							Matcher m = r.matcher(line);
							if (m.find()) {
								if ("java.version".equalsIgnoreCase(m.group(1))) {
									reportMetaData.setJavaVersion(line);
								} else if ("java-version".equalsIgnoreCase(m.group(1))) {
									reportMetaData.setJavaVersion(line);
								} else if ("<source>".equalsIgnoreCase(m.group(1))) {
									reportMetaData.setJavaVersion(line);
								} else if ("<maven.compiler.source>".equalsIgnoreCase(m.group(1))) {
									reportMetaData.setJavaVersion(line);
								} else if ("<packaging>".equalsIgnoreCase(m.group(1))) {
									reportMetaData.setDeploymentPackageing(line);
								}
							}
						}
					});
				}
				return FileVisitResult.CONTINUE;
			}
		});
		reportMetaData.setTotalNoOfLines(totalNoOfLines.toString());

		return reportMetaData;
	}

	private String getBuildTool(String matches) {
		String message = "No build tool found in your code base.";
		if("<ivy-module".equalsIgnoreCase(matches)) {
			message = "You are using Ivy build tool. So the difficulty level is Medium.";
		} else if("<modelVersion>".equalsIgnoreCase(matches)) {
			message = "You are using Maven build tool. So the difficulty level is Small.";
		} 
		return message;
	}
	
	private String getRecommendation(String matches) {
		String message = null;
		if (LoggingConstants.LOG4J_ROLLINGFILE_APPENDER_KEYWORD.equalsIgnoreCase(matches)
				|| LoggingConstants.LOG4J_FILE_APPENDER_KEYWORD.equalsIgnoreCase(matches)) {
			message = LoggingConstants.LOG4J_RECOMMENDATION;
		} else if (LoggingConstants.LOGBACK_FILE_APPENDER_KEYWORD.equalsIgnoreCase(matches)) {
			message = LoggingConstants.LOGBACK_RECOMMENDATION;
		} else if ("HttpSession".equalsIgnoreCase(matches)) {
			message = LoggingConstants.STICKY_SESSION_RECOMMENDATION;
		} else if ("@Scope(\"session\")".equalsIgnoreCase(matches)) {
			message = LoggingConstants.STICKY_SESSION_RECOMMENDATION;
		} else if ("scope=\"session\"".equalsIgnoreCase(matches)) {
			message = LoggingConstants.STICKY_SESSION_RECOMMENDATION;
		} else if ("scope =\"session\"".equalsIgnoreCase(matches)) {
			message = LoggingConstants.STICKY_SESSION_RECOMMENDATION;
		} else if ("@SessionAttributes".equalsIgnoreCase(matches)) {
			message = LoggingConstants.STICKY_SESSION_RECOMMENDATION;
		} else if ("org.apache.struts2.interceptor.SessionAware".equalsIgnoreCase(matches)) {
			message = LoggingConstants.STICKY_SESSION_RECOMMENDATION;
		} else if ("SessionAware".equalsIgnoreCase(matches)) {
			message = LoggingConstants.STICKY_SESSION_RECOMMENDATION;
		} else if ("javax.faces.bean.SessionScoped".equalsIgnoreCase(matches)) {
			message = LoggingConstants.STICKY_SESSION_RECOMMENDATION;
		} else if ("@SessionScoped".equalsIgnoreCase(matches)) {
			message = LoggingConstants.STICKY_SESSION_RECOMMENDATION;
		} else if (matches != null && (matches.contains(".gemfire.") || matches.contains(".geode."))) {
			message = LoggingConstants.GEMFIRE_EFFORT_RECOMMENDATION;
		} else if ("spring-data-gemfire".equalsIgnoreCase("matches")) {
			message = LoggingConstants.GEMFIRE_EFFORT_RECOMMENDATION;
		} else if ("hazelcast".equalsIgnoreCase("matches")) {
			message = LoggingConstants.HAZELCAST_EFFORT_RECOMMENDATION;
		} else if ("rabbitmq-jms".equalsIgnoreCase("matches")) {
			message = LoggingConstants.RABBITMQ_EFFORT_RECOMMENDATION;
		} else if ("rabbitmq-client".equalsIgnoreCase("matches")) {
			message = LoggingConstants.RABBITMQ_EFFORT_RECOMMENDATION;
		} else if ("<groupId>com.rabbitmq</groupId>".equalsIgnoreCase("matches")
				|| "com.rabbitmq".equalsIgnoreCase("matches")) {
			message = LoggingConstants.RABBITMQ_EFFORT_RECOMMENDATION;
		} else if ("<artifactId>amqp-client</artifactId>".equalsIgnoreCase("matches")) {
			message = LoggingConstants.RABBITMQ_EFFORT_RECOMMENDATION;
		} else if ("amqp-client".equalsIgnoreCase("matches")) {
			message = LoggingConstants.RABBITMQ_EFFORT_RECOMMENDATION;
		} else if ("spring-rabbit".equalsIgnoreCase("matches") || "spring-amqp".equalsIgnoreCase("matches")
				|| "org.motechproject.org.springframework.amqp".equalsIgnoreCase("matches")) {
			message = LoggingConstants.RABBITMQ_EFFORT_RECOMMENDATION;
		} else if ("com.ibm.mq".equalsIgnoreCase("matches") || "com.ibm.mq.allclient".equalsIgnoreCase("matches")
				|| "com.ibm.mqjms".equalsIgnoreCase("matches") || "com.ibm.mq.pcf".equalsIgnoreCase("matches")
				|| "com.ibm.mq.allclient.jar".equalsIgnoreCase("matches")) {
			message = LoggingConstants.IBMMQ_EFFORT_RECOMMENDATION;
		} else if ("javax.jms-api".equalsIgnoreCase("matches") || "jms-api".equalsIgnoreCase("matches")
				|| "com.springsource.javax.jms".equalsIgnoreCase("matches")) {
			message = LoggingConstants.JMS_EFFORT_RECOMMENDATION;
		}  
		return message;
	}

	// To show all searchs by user
	public List<SearchMetaData> getSearchHistory(String uuid) throws IOException {
		List<SearchMetaData> listSearchMetaData = new ArrayList<>();
		try {
			String uUID = java.util.UUID.fromString(uuid).toString();
			listSearchMetaData = searchMetaDataRepository.findByUUID(uUID);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return listSearchMetaData;
	}

	// To fetch data for Edit Search history section
	public SearchMetaData getSearchMetaDataByUUIDAndTagName(String uuid, String tagName) {
		SearchMetaData searchMetaData = null;
		try {
			String uUID = java.util.UUID.fromString(uuid).toString();
			searchMetaData = searchMetaDataRepository.getSearchMetaDataByUUIDAndTagName(uUID, tagName);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return searchMetaData;
	}

	// To delete record from Search history
	public void deleteSearchMetaDataByUUIDAndTagName(String uUID, String tagName) {
		try {
			searchMetaDataRepository.deleteSearchMetaDataByUUIDAndTagName(uUID, tagName);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}

	private SearchMetaData saveSearchMetaData(String localGitRepoPath, String tagName) {
		SearchMetaData searchMetaData = new SearchMetaData();
		String uUID = UUID.randomUUID().toString();
		System.out.println("UUID =" + uUID);
		searchMetaData.setLocalGitRepoPath(localGitRepoPath);
		searchMetaData.setuUID(uUID);
		searchMetaData.setTagName("HK");
		SearchMetaData saveResult = searchMetaDataRepository.save(searchMetaData);
		return saveResult;
	}

	private String cloneGitRepository(String path) throws GitAPIException, InvalidRemoteException, TransportException {
		String localGitRepoPath;
		Random random = new Random();
		localGitRepoPath = "C:\\gitRepo\\" + random.nextInt();
		logger.info("localGitRepoPath: " + localGitRepoPath);
		Git.cloneRepository().setURI(path).setDirectory(new File(localGitRepoPath)).call();
		return localGitRepoPath;
	}

	private void deleteLocalGitRepo(String localGitRepoPath) {
		File file = new File(localGitRepoPath);
		// Deleting the directory recursively with SpringUtil.
		if (!FileSystemUtils.deleteRecursively(file)) {
			logger.info("Problem occurs when deleting the directory: " + localGitRepoPath);
		}
	}

	private List<SearchResults> searchService(String path, String pattern) {
		List<SearchResults> listSearchResults = new ArrayList<>();
		try {
			FileVisitor<Path> simpleFileVisitor = new SimpleFileVisitor<Path>() {
				@Override
				public FileVisitResult visitFile(Path visitedFile, BasicFileAttributes fileAttributes)
						throws IOException {
					Pattern r = Pattern.compile(pattern);
					if (visitedFile.toFile().getPath().matches(".*(xml|properties|java).*")
							&& !visitedFile.toFile().getPath().matches(".*\\target\\.*")) {
						Stream<String> strString = grep(visitedFile.toFile().getPath(), pattern);
						List<String> list = new ArrayList<String>();
						strString.forEach(line -> {
							SearchResults searchResults = new SearchResults();
							if (Pattern.matches(pattern, line)) {
								Matcher m = r.matcher(line);
								if (m.find()) {
									searchResults.setRecommendations(getRecommendation(m.group(1)));
									searchResults.setFilePath(visitedFile.toFile().getPath());
									list.add(line);
									searchResults.setCodeLines(list);
								}
								listSearchResults.add(searchResults);
							}
						});
					}

					return FileVisitResult.CONTINUE;
				}
			};
			FileSystem fileSystem = FileSystems.getDefault();
			Path rootPath = fileSystem.getPath(path); // path
			Files.walkFileTree(rootPath, simpleFileVisitor);
		} catch (IOException ioe) {
			logger.error("IOException occured in GrepService.searchService()");
		}
		return listSearchResults;
	}

	private long linesCount(String path) throws IOException {
		return Files.lines(Paths.get(path), StandardCharsets.ISO_8859_1).count();
	}

	public Stream<String> grep(String path, String pattern) throws IOException {

		return Files.lines(Paths.get(path), StandardCharsets.ISO_8859_1).filter(line -> line.matches(pattern));
	}

}
